console.log("Alphabets from (a-z) are:"); 
console.log(`ASCII character : ${String.fromCharCode(32)} (space) is = 32`);
for (i = 33; i <= 126; i++) {
  console.log(`ASCII character : ${String.fromCharCode(i)} and its value is ${i}`);

}