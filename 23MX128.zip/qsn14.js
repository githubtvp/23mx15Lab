console.log('x value raised to power n :')
let x = 5;
let n = 4;
let result = 1;
while (n != 0 )
{
  result *= x;   
  n--;
}
console.log(result);