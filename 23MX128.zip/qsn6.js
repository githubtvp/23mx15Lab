console.log("Print multiplication table ");
let m = 4;
let n = 1;
let result = 0;
let max = 16;
console.log("Multiplication table for m = " + m);
while (n <= max) 
{
  result = m * n;
  console.log(`${m} x ${n} = ${result}`);
  n++;
}      
 