console.log("Print 1 to n "); 
let n = 10;
console.log("n = " + n); 
 let x = 1; 
 while( x <= n)       
 {
  console.log(x);
  x++;
 }           
 